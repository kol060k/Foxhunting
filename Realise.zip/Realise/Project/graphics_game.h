void draw_back()
{
    glRasterPos2i(width/2 - w_but/2, height_back_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_back);
}
void draw_counter()
#define height_pan 60
#define shift_pan 40
#define deep_counter 75
#define deep_time 45
{
    glColor3ub(89, 46, 0);
    glBegin(GL_QUADS);
      glVertex2f(width / 2 - shift_res - shift_pan, height - attic / 2 + height_pan / 2);
      glVertex2f(width / 2 - shift_res - shift_pan, height - attic / 2 - height_pan / 2);
      glVertex2f(width / 2 + shift_res + shift_pan, height - attic / 2 - height_pan / 2);
      glVertex2f(width / 2 + shift_res + shift_pan, height - attic / 2 + height_pan / 2);
    glEnd();

    glRasterPos2i(count_pos_x_AI, count_pos_y);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_number[a_foxleft]);

    glRasterPos2i(count_pos_x_player, count_pos_y);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_number[p_foxleft]);

    char c = '0';
    c += xod % 100 / 10;
    glRasterPos2i(width/2 - wchar, height - deep_counter);
    DRAWCHAR(c);

    c = '0';
    c += xod % 10;
    glRasterPos2i(width/2, height - deep_counter);
    DRAWCHAR(c);

    if (xod != 0)
    {
        int t = time1 - time0;
        ts[4] = '0';
        ts[4] += t % 10;
        ts[3] = '0';
        ts[3] += (t % 60) / 10;

        ts[1] = '0';
        ts[1] += (t % 600) / 60;
        ts[0] = '0';
        ts[0] += (t % 3600) / 600;
    }
    else
    {
        ts[4] = '0';
        ts[3] = '0';

        ts[1] = '0';
        ts[0] = '0';
    }
    write_string((width - 5*wchar)/2, height - deep_time, ts, 5);
}

void draw_flag(const int i, const int j)
{
    glColor3ub(64, 0, 64);
    glBegin(GL_QUADS);
      glVertex2f(rim + i * size_cell + 1, rim + (j + 1) * size_cell - 1);
      glVertex2f(rim + i * size_cell + 1, rim + j * size_cell + 1);
      glVertex2f(rim + (i + 1) * size_cell - 1, rim + j * size_cell + 1);
      glVertex2f(rim + (i + 1) * size_cell - 1, rim + (j + 1) * size_cell - 1);
    glEnd();

    glColor3ub(128, 0, 128);
    glBegin(GL_QUADS);
      glVertex2f(rim + i * size_cell + depth_of_cell, rim + (j + 1) * size_cell - depth_of_cell);
      glVertex2f(rim + i * size_cell + depth_of_cell, rim + j * size_cell + depth_of_cell);
      glVertex2f(rim + (i + 1) * size_cell - depth_of_cell, rim + j * size_cell + depth_of_cell);
      glVertex2f(rim + (i + 1) * size_cell - depth_of_cell, rim + (j + 1) * size_cell - depth_of_cell);
    glEnd();
}

void draw_number(const int i, const int j, const int field, const int num)
{
    glRasterPos2i(rim + field * origin2 + i * size_cell + 1, rim + j * size_cell + 1);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_number[num]);
}

void draw_tree(const int i, const int j, const int field)
{
    glRasterPos2i(rim + field * origin2 + i * size_cell + 1, rim + j * size_cell + 1);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_tree);
}

void draw_body(const int i, const int j, const int field)
{
    glRasterPos2i(rim + field * origin2 + i * size_cell + 1, rim + j * size_cell + 1);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_body);
}

void draw_fox(const int i, const int j, const int field)
{
    glRasterPos2i(rim + field * origin2 + i * size_cell + 1, rim + j * size_cell + 1);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_fox);
}

void draw_empty(const int i, const int j, const int field)
{
    glColor3ub(0, 64, 0);
    glBegin(GL_QUADS);
      glVertex2f(rim + field * origin2 + i * size_cell + 1, rim + (j + 1) * size_cell - 1);
      glVertex2f(rim + field * origin2 + i * size_cell + 1, rim + j * size_cell + 1);
      glVertex2f(rim + field * origin2 + (i + 1) * size_cell - 1, rim + j * size_cell + 1);
      glVertex2f(rim + field * origin2 + (i + 1) * size_cell - 1, rim + (j + 1) * size_cell - 1);
    glEnd();

    glColor3ub(0, 128, 0);
    glBegin(GL_QUADS);
      glVertex2f(rim + field * origin2 + i * size_cell + depth_of_cell, rim + (j + 1) * size_cell - depth_of_cell);
      glVertex2f(rim + field * origin2 + i * size_cell + depth_of_cell, rim + j * size_cell + depth_of_cell);
      glVertex2f(rim + field * origin2 + (i + 1) * size_cell - depth_of_cell, rim + j * size_cell + depth_of_cell);
      glVertex2f(rim + field * origin2 + (i + 1) * size_cell - depth_of_cell, rim + (j + 1) * size_cell - depth_of_cell);
    glEnd();
}

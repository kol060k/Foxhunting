int move_numb = 0, beg_shots = 0;  // move_numb - number of moves have done since game starting, beg_shots - number of random shots AI did at the beginning



int p1[10][10], p2[10][10], a[10][10];
					// p1 - field with AI foxes for player;  p2 - massive with player's foxes for player;
					// a - field for AI algorithm
int fox_number = 10, tree_number = 0;  // Number of foxes and trees in game

int p_foxleft = 10, p_foxleft1 = 10, a_foxleft = 10, a_foxleft1 = 10;  // Number of player's/AI foxes left

int xod = 0;

void init_game()  // Initialize game fields, tree and fox positions
	// p1 - field with AI foxes for player;  p2 - massive with player's foxes for player;
	// a - field for AI algorithm
	// 0 - number for empty position, -1 - fox position, -2 - tree position, -3 - fox body position
{
	int i, j, x, y;
	for (i = 0; i < 10; i++)
		for (j = 0; j < 10; j++)
			p1[i][j] = p2[i][j] = a[i][j] = 0;
	if (tree_number == 0) tree_number = rand() % 3 + 2;  // Generating number of trees if it's not set at the beginning
	for (i = 0; i < tree_number; i++)  // Generating tree positions for both player and AI (trees have the same positions)
	{
		x = rand() % 10;
		y = rand() % 10;
		if (p1[x][y] != -2)
			p1[x][y] = p2[x][y] = a[x][y] = -2;
		else i--;
	}
	for (i = 0; i < fox_number; i++)         // Generating fox positions for player
	{
		x = rand() % 10;
		y = rand() % 10;
		if ((p2[x][y] != -2) && (p2[x][y] != -1))
			p2[x][y] = -1;
		else i--;
	}
	for (i = 0; i < fox_number; i++)         // Generating fox positions for AI
	{
		x = rand() % 10;
		y = rand() % 10;
		if ((p1[x][y] != -2) && (p1[x][y] != -1))
			p1[x][y] = -1;
		else i--;
	}
	p_foxleft = p_foxleft1 = a_foxleft = a_foxleft1 = fox_number;
}



////////////BASIC FUNCTIONS///////////////

int find_fox(int p[10][10], int m, int n, int setting)  // Function of searching foxes in strings, columns and diagonals
// if (setting == -3) then we count dead foxes
// else we don't count
{
	int numb = 0, i, j;
	for (i = m - 1; i >= 0; i--)  // Going up
	{
		if (p[i][n] == -2) break;
		if (p[i][n] == -1) numb++;
		if ((p[i][n] == -3) && (setting == -3)) numb++;
	}
	for (i = m + 1; i < 10; i++)  // Going down
	{
		if (p[i][n] == -2) break;
		if (p[i][n] == -1) numb++;
		if ((p[i][n] == -3) && (setting == -3)) numb++;
	}
	for (j = n - 1; j >= 0; j--)  // Going left
	{
		if (p[m][j] == -2) break;
		if (p[m][j] == -1) numb++;
		if ((p[m][j] == -3) && (setting == -3)) numb++;
	}
	for (j = n + 1; j < 10; j++)  // Going right
	{
		if (p[m][j] == -2) break;
		if (p[m][j] == -1) numb++;
		if ((p[m][j] == -3) && (setting == -3)) numb++;
	}
	for (i = m - 1, j = n - 1; (i >= 0) && (j >= 0); i--, j--)  // Going up and left
	{
		if (p[i][j] == -2) break;
		if (p[i][j] == -1) numb++;
		if ((p[i][j] == -3) && (setting == -3)) numb++;
	}
	for (i = m + 1, j = n - 1; (i < 10) && (j >= 0); i++, j--)  // Going down and left
	{
		if (p[i][j] == -2) break;
		if (p[i][j] == -1) numb++;
		if ((p[i][j] == -3) && (setting == -3)) numb++;
	}
	for (i = m - 1, j = n + 1; (i >= 0) && (j < 10); i--, j++)  // Going up and right
	{
		if (p[i][j] == -2) break;
		if (p[i][j] == -1) numb++;
		if ((p[i][j] == -3) && (setting == -3)) numb++;
	}
	for (i = m + 1, j = n + 1; (i < 10) && (j < 10); i++, j++)  // Going down and right
	{
		if (p[i][j] == -2) break;
		if (p[i][j] == -1) numb++;
		if ((p[i][j] == -3) && (setting == -3)) numb++;
	}
	return numb;
}

int player_move(int x, int y, int a_foxleft)  // Function that works with player's turn
{
	if (p1[x][y] == 0) p1[x][y] = find_fox(p1, x, y, -3);
	else
	{
		p1[x][y] = -3;
		a_foxleft--;
	}
	if (p1[x][y] == 0) p1[x][y] = -10;  // If there is no one foxes in string, column and diagonals, we still need to mark the cell that player shooted here
	return a_foxleft;
}

int random_shoot(int p_foxleft)  // Starting random AI shots
{
	int m, n, right_shot = 0;  // m, n - numbers of string and column; right_shot - checker if shot correct
	while (right_shot == 0)
	{
		m = rand() % 10;
		n = rand() % 10;
		if ((p2[m][n] == 0) || (p2[m][n] == -1))
			right_shot = 1;
	}
	if (p2[m][n] == 0)
	{
		p2[m][n] = find_fox(p2, m, n, -3);
	}
	else
	{
		a[m][n] = -10;
		p2[m][n] = -3;
		p_foxleft--;
	}
	if (p2[m][n] == 0) p2[m][n] = -10;  // If there is no one foxes in string, column and diagonals, we still need to mark the cell that player shooted here
	return p_foxleft;
}

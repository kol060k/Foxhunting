#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <GL/glut.h>

#include "GLdefs.h"
#include "functions.h"

int flags[10][10];

void draw_counter()
#define height_pan 60
#define shift_pan 40
{
    glColor3ub(89, 46, 0);
    glBegin(GL_QUADS);
      glVertex2f(width / 2 - shift_res - shift_pan, height - attic / 2 + height_pan / 2);
      glVertex2f(width / 2 - shift_res - shift_pan, height - attic / 2 - height_pan / 2);
      glVertex2f(width / 2 + shift_res + shift_pan, height - attic / 2 - height_pan / 2);
      glVertex2f(width / 2 + shift_res + shift_pan, height - attic / 2 + height_pan / 2);
    glEnd();

    glRasterPos2i(count_pos_x_AI, count_pos_y);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_number[a_foxleft]);

    glRasterPos2i(count_pos_x_player, count_pos_y);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_number[p_foxleft]);
}

void draw_flag(const int i, const int j)
{
    glColor3ub(64, 0, 64);
    glBegin(GL_QUADS);
      glVertex2f(rim + i * size_cell + 1, rim + (j + 1) * size_cell - 1);
      glVertex2f(rim + i * size_cell + 1, rim + j * size_cell + 1);
      glVertex2f(rim + (i + 1) * size_cell - 1, rim + j * size_cell + 1);
      glVertex2f(rim + (i + 1) * size_cell - 1, rim + (j + 1) * size_cell - 1);
    glEnd();

    glColor3ub(128, 0, 128);
    glBegin(GL_QUADS);
      glVertex2f(rim + i * size_cell + depth_of_cell, rim + (j + 1) * size_cell - depth_of_cell);
      glVertex2f(rim + i * size_cell + depth_of_cell, rim + j * size_cell + depth_of_cell);
      glVertex2f(rim + (i + 1) * size_cell - depth_of_cell, rim + j * size_cell + depth_of_cell);
      glVertex2f(rim + (i + 1) * size_cell - depth_of_cell, rim + (j + 1) * size_cell - depth_of_cell);
    glEnd();
}

void draw_number(const int i, const int j, const int field, const int num)
{
    glRasterPos2i(rim + field * origin2 + i * size_cell + 1, rim + j * size_cell + 1);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_number[num]);
}

void draw_tree(const int i, const int j, const int field)
{
    glRasterPos2i(rim + field * origin2 + i * size_cell + 1, rim + j * size_cell + 1);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_tree);
}

void draw_body(const int i, const int j, const int field)
{
    glRasterPos2i(rim + field * origin2 + i * size_cell + 1, rim + j * size_cell + 1);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_body);
}

void draw_fox(const int i, const int j, const int field)
{
    glRasterPos2i(rim + field * origin2 + i * size_cell + 1, rim + j * size_cell + 1);
    glDrawPixels(
        size_im,
        size_im,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_fox);
}

void draw_empty(const int i, const int j, const int field)
{
    glColor3ub(0, 64, 0);
    glBegin(GL_QUADS);
      glVertex2f(rim + field * origin2 + i * size_cell + 1, rim + (j + 1) * size_cell - 1);
      glVertex2f(rim + field * origin2 + i * size_cell + 1, rim + j * size_cell + 1);
      glVertex2f(rim + field * origin2 + (i + 1) * size_cell - 1, rim + j * size_cell + 1);
      glVertex2f(rim + field * origin2 + (i + 1) * size_cell - 1, rim + (j + 1) * size_cell - 1);
    glEnd();

    glColor3ub(0, 128, 0);
    glBegin(GL_QUADS);
      glVertex2f(rim + field * origin2 + i * size_cell + depth_of_cell, rim + (j + 1) * size_cell - depth_of_cell);
      glVertex2f(rim + field * origin2 + i * size_cell + depth_of_cell, rim + j * size_cell + depth_of_cell);
      glVertex2f(rim + field * origin2 + (i + 1) * size_cell - depth_of_cell, rim + j * size_cell + depth_of_cell);
      glVertex2f(rim + field * origin2 + (i + 1) * size_cell - depth_of_cell, rim + (j + 1) * size_cell - depth_of_cell);
    glEnd();
}

void Display(void) // ��������� ������
{
    glClearColor(0.184, 0.105, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);

    if ((p_foxleft > 0) && (a_foxleft > 0))
    {
        draw_counter();
    }
    else
    {
        if (p_foxleft == 0)
        {
            glColor3ub(255, 0, 0);
        }
        else
        {
            glColor3ub(0, 255, 0);
        }
        glBegin(GL_QUADS);
            glVertex2f(width / 2 - shift_res - shift_pan, height - attic / 2 + height_pan / 2);
            glVertex2f(width / 2 - shift_res - shift_pan, height - attic / 2 - height_pan / 2);
            glVertex2f(width / 2 + shift_res + shift_pan, height - attic / 2 - height_pan / 2);
            glVertex2f(width / 2 + shift_res + shift_pan, height - attic / 2 + height_pan / 2);
        glEnd();
    }

    int i, j;

    for (i = 0; i < 10; ++i)
    {
        for (j = 0; j < 10; ++j)
        {
            if (flags[i][j] == 1)
            {
                draw_flag(i, j);
            }
            else
            {
                if (p1[i][j] > 0)
                {
                    draw_number(i, j, 0, p1[i][j]);
                }
                else
                {
                    switch(p1[i][j])
                    {
                    case -1:
                        draw_empty(i, j, 0);
                        break;
                    case -2:
                        draw_tree(i, j, 0);
                        break;
                    case -3:
                        draw_body(i, j, 0);
                        break;
                    case -10:
                        draw_number(i, j, 0, 0);
                        break;
                    case 0:
                        draw_empty(i, j, 0);
                        break;
                    }
                }
            }
        }
    }

    for (i = 0; i < 10; ++i)
    {
        for (j = 0; j < 10; ++j)
        {
            if (p2[i][j] > 0)
            {
                draw_number(i, j, 1, p2[i][j]);
            }
            else
            {
                switch(p2[i][j])
                {
                case -1:
                    draw_fox(i, j, 1);
                    break;
                case -2:
                    draw_tree(i, j, 1);
                    break;
                case -3:
                    draw_body(i, j, 1);
                    break;
                case -10:
                    draw_number(i, j, 1, 0);
                    break;
                case 0:
                    draw_empty(i, j, 1);
                    break;
                }
            }
        }
    }



    glutSwapBuffers();
    glFinish();
}


void Reshape(GLint w, GLint h) /* ������� ���������� ��� ��������� �������� ���� */
{

    /* ������������� ������� ������� ����������� */
    glViewport(0, 0, w, h);

    /* ��������������� �������� */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, w, 0, h, -1.0, 1.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}


void Keyboard(unsigned char key, int x, int y) /* ������� ������������ ��������� �� ���������� */
{
#define ESCAPE '\033'

    if( key == ESCAPE )
        exit(0);
}

void MouseFunc(int button, int state, int x, int y) // ������ �������� ���� - �������� int main()
{
    int i,j;
    if ((state == 0) && (y >= attic) && (x >= rim))
    {
        y -= attic;
        if (y < height - rim - attic)
        {
            if (x <= 10 * size_cell + rim)
            {
                x -= rim;
                x /= size_cell;
                y /= size_cell;
                y = 9 - y;
                switch(button)
                {
                case GLUT_LEFT_BUTTON:
                    if (((p1[x][y] == -1) || (p1[x][y] == 0)) && (flags[x][y] == 0) && (a_foxleft > 0) && (p_foxleft > 0))
                    {
                        generous_mozg(x, y);
                    }
                    break;
                case GLUT_RIGHT_BUTTON:
                    if ((flags[x][y] == 0) && ((p1[x][y] == 0) || (p1[x][y] == -1)))
                    {
                        flags[x][y] = 1;
                    }
                    else
                    {
                        if ((p1[x][y] == 0) || (p1[x][y] == -1))
                            flags[x][y] = 0;
                    }
                    break;
                }
            }
        }
    }

    glutPostRedisplay();
}

int main(int argc, char *argv[])
{
    int i, j;
    for (i = 0; i < 10; ++i)
    {
        for (i = 0; i < 10; ++i)
        {
            flags[i][j] = 0;
        }
    }
    printf("Enter number of foxes in field (>0): ");  // You can change number of foxes at the beginning
	scanf("%d", &fox_number);
	if (fox_number <= 0) fox_number = 10;
	printf("Enter number of trees in field (0 - randomly generating): ");  // You can change number of trees at the beginning
	scanf("%d", &tree_number);
	srand(time(NULL));
	init_game();




    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB);
    glutInitWindowSize(width, height);
    glutCreateWindow("Fox Hunting 1.0");

    glutDisplayFunc(Display);
    glutReshapeFunc(Reshape);
    glutKeyboardFunc(Keyboard);
    glutMouseFunc(MouseFunc);

    glutMainLoop();

    return 0;
}

#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <GL/glut.h>

#include "GLdefs.h"
#include "InitGame.h"
#include "HardAI.h"
#include "MediumAI.h"
#include "RandomAI.h"

#include "load_textures.h"
#include "graphics_start.h"
#include "graphics_game.h"

void Display(void) // ��������� ������
#define w_shift_enter 50
#define h_enter 250
#define h_shift_enter 40
#define shift_enter 15
{
    glClearColor(0.184, 0.105, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);

	switch(win_stat) {
    case START:
        {
            draw_FH();
            draw_buttons();
            draw_cat();
        }
        break;
    case OPTIONS:
        {
            draw_FH();
            draw_buttons_options();
            draw_cat();

            glColor3ub(89, 46, 0);
            glBegin(GL_QUADS);
              glVertex2f(width/2 + w_shift_enter - shift_enter, h_enter + shift_enter + h_shift_enter + 20);
              glVertex2f(width/2 + w_shift_enter - shift_enter, h_enter - shift_enter);
              glVertex2f(width/2 + w_shift_enter + shift_enter + wchar*(num1st + 3), h_enter - shift_enter);
              glVertex2f(width/2 + w_shift_enter + shift_enter + wchar*(num1st + 3), h_enter + shift_enter + h_shift_enter + 20);
            glEnd();
            write_string(width/2 + w_shift_enter, h_enter + h_shift_enter, enter_foxes, num1st+3);
            write_string(width/2 + w_shift_enter, h_enter, enter_tree, num1st + 3);
        }
		break;
	case GAME:
        {
			if ((p_foxleft > 0) && (a_foxleft > 0))
			{
				draw_counter();
			}
			else
			{
				if (p_foxleft == 0)
				{
					glColor3ub(255, 0, 0);
				}
				else
				{
					glColor3ub(0, 255, 0);
				}
				glBegin(GL_QUADS);
				glVertex2f(width / 2 - shift_res - shift_pan, height - attic / 2 + height_pan / 2);
				glVertex2f(width / 2 - shift_res - shift_pan, height - attic / 2 - height_pan / 2);
				glVertex2f(width / 2 + shift_res + shift_pan, height - attic / 2 - height_pan / 2);
				glVertex2f(width / 2 + shift_res + shift_pan, height - attic / 2 + height_pan / 2);
				glEnd();
			}

			int i, j;

			for (i = 0; i < 10; ++i)
			{
				for (j = 0; j < 10; ++j)
				{
					if (flags[i][j] == 1)
					{
						draw_flag(i, j);
					}
					else
					{
						if (p1[i][j] > 0)
						{
							draw_number(i, j, 0, p1[i][j]);
						}
						else
						{
							switch (p1[i][j])
							{
							case -1:
								draw_empty(i, j, 0);
								break;
							case -2:
								draw_tree(i, j, 0);
								break;
							case -3:
								draw_body(i, j, 0);
								break;
							case -10:
								draw_number(i, j, 0, 0);
								break;
							case 0:
								draw_empty(i, j, 0);
								break;
							}
						}
					}
				}
			}

			for (i = 0; i < 10; ++i)
			{
				for (j = 0; j < 10; ++j)
				{
					if (p2[i][j] > 0)
					{
						draw_number(i, j, 1, p2[i][j]);
					}
					else
					{
						switch (p2[i][j])
						{
						case -1:
							draw_fox(i, j, 1);
							break;
						case -2:
							draw_tree(i, j, 1);
							break;
						case -3:
							draw_body(i, j, 1);
							break;
						case -10:
							draw_number(i, j, 1, 0);
							break;
						case 0:
							draw_empty(i, j, 1);
							break;
						}
					}
				}
			}
		}
		break;
    case RESULT:
        {
            draw_back();
        }
        break;
    case TABLE_REC:
        {
            draw_back();
            draw_cat();
        }
        break;
    case HELP:
        {
            draw_back();

            glRasterPos2i(width/2 - w_helps/2, 100);
            glDrawPixels(
                w_helps,
                h_helps,
                GL_RGB,
                GL_UNSIGNED_BYTE,
                im_help);

            draw_cat();
        }
        break;
    case PAUSE:
        {

        }
        break;
    case ABOUT:
        {
            draw_back();
            draw_cat();
        }
        break;
	}

	glutSwapBuffers();
	glFinish();
}



void Reshape(GLint w, GLint h) /* ������� ���������� ��� ��������� �������� ���� */
{
    /* ������������� ������� ������� ����������� */
    real_width = w;
    real_height = h;
    glViewport(0, 0, w, h);

    /* ��������������� �������� */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, w, 0, h, -1.0, 1.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}


void Keyboard(unsigned char key, int x, int y) /* ������� ������������ ��������� �� ���������� */
{
#define ESCAPE 27
    if(key == ESCAPE)
    {
        if ((p_foxleft == 0) || (a_foxleft == 0))
            win_stat = START;
    }
    switch(win_stat) {
    case START:
        {

        }
		break;
    case OPTIONS:
        {
            switch(opt_enter){
            case NO:
                break;
            case TREE:
                if ((key >= '0') && (key <= '9'))
                {
                    if (stack_enter_tree < 2)
                    {
                        enter_tree[num1st + stack_enter_tree] = key;
                        ++stack_enter_tree;
                    }
                }
                if (key == 8)
                {
                    if (stack_enter_tree > 0)
                    {
                        --stack_enter_tree;
                        enter_tree[num1st + stack_enter_tree] = ' ';
                    }
                }
                break;
            case FOX:
                if ((key >= '0') && (key <= '9'))
                {
                    if (stack_enter_fox < 2)
                    {
                        enter_foxes[num1st + stack_enter_fox] = key;
                        ++stack_enter_fox;
                    }
                }
                if (key == 8)
                {
                    if (stack_enter_fox > 0)
                    {
                        --stack_enter_fox;
                        enter_foxes[num1st + stack_enter_fox] = ' ';
                    }
                }
                break;
            };

        }
        break;
	case GAME:
        {

        }
		break;
    case RESULT:
        {

        }
        break;
    case TABLE_REC:
        {

        }
        break;
    case HELP:
        {

        }
        break;
    case PAUSE:
        {

        }
        break;
    case ABOUT:
        {

        }
        break;
	}
    glutPostRedisplay();
}

void options_click()
{
    if (stack_enter_fox > 0)
    {
        if (stack_enter_fox == 1)
        {
            fox_number = enter_foxes[num1st] - '0';
            if (fox_number <= 0)
                fox_number = 10;
        }
        else
        {
            fox_number = enter_foxes[num1st + 1] - '0';
            fox_number += 10*(enter_foxes[num1st] - '0');
            if ((fox_number <= 0) || (fox_number > 10))
                fox_number = 10;
        }
        stack_enter_fox = 0;
    }
    if (stack_enter_tree > 0)
    {
        if (stack_enter_tree == 1)
        {
            tree_number = enter_tree[num1st] - '0';
            if (tree_number <= 0)
                tree_number = 10;
        }
        else
        {
            tree_number = enter_tree[num1st + 1] - '0';
            tree_number += 10*(enter_tree[num1st] - '0');
            if (tree_number <= 0)
                tree_number = 10;
        }
        stack_enter_tree = 0;
    }
    win_stat = GAME;
}

void click_back(int x, int y)
{
    if ((x > width/2 - w_but/2) && (x < width/2 + w_but/2))
        if ((y > height_back_button) && (y < height_back_button + h_but))
        {
            win_stat = last_win_stat;
        }
}
void MouseFunc(int button, int state, int x, int y) // ������ �������� ����
{
    if (win_stat != GAME) // <�������> ����� �� ������� ������ ���������
    {
        y = real_height - y;
    }
    if (state == 0)
    {
    switch(win_stat) {
    case START:
        {
            if ((x > (width - w_but)/2) && (x < (width + w_but)/2))
                if ((y > height_button + 3*shift_height_button) && (y < height_button + 3*shift_height_button + h_but))
                    win_stat = OPTIONS;
            if ((x > (width - w_but)/2) && (x < (width + w_but)/2))
                if ((y > height_button + 2*shift_height_button) && (y < height_button + 2*shift_height_button + h_but))
                    win_stat = TABLE_REC;
            if ((x > (width - w_but)/2) && (x < (width + w_but)/2))
                if ((y > height_button + shift_height_button) && (y < height_button + shift_height_button + h_but))
                {
                    last_win_stat = START;
                    win_stat = HELP;
                }
            if ((x > (width - w_but)/2) && (x < (width + w_but)/2))
                if ((y > height_button) && (y < height_button + h_but))
                    win_stat = ABOUT;
        }
		break;
    case OPTIONS:
        {
            if ((x > (width - w_but)/2 - shift_button) && (x < (width + w_but)/2 - shift_button))
                if ((y > height_button + 3*shift_height_button) && (y < height_button + 3*shift_height_button + h_but))
                {
                    game_stat = HARD;
                    options_click();
                    init_game();
                }
            if ((x > (width - w_but)/2 - shift_button) && (x < (width + w_but)/2 - shift_button))
                if ((y > height_button + 2*shift_height_button) && (y < height_button + 2*shift_height_button + h_but))
                {
                    game_stat = MEDIUM;
                    options_click();
                    init_game();
                }
            if ((x > (width - w_but)/2 - shift_button) && (x < (width + w_but)/2 - shift_button))
                if ((y > height_button + shift_height_button) && (y < height_button + shift_height_button + h_but))
                {
                    game_stat = EASY;
                    options_click();
                    init_game();
                }
            if ((x > (width - w_but)/2 - shift_button) && (x < (width + w_but)/2 - shift_button))
                if ((y > height_back_button) && (y < height_back_button + h_but))
                    win_stat = START;

            if ((x > width/2 + w_shift_enter) && (x < width/2 + w_shift_enter + wchar*(num1st + 3)))
            {
                if ((y > h_enter + h_shift_enter) && (y < h_enter + h_shift_enter + 20))
                {
                    opt_enter = FOX;
                    stack_enter_fox = 0;
                    enter_foxes[num1st] = ' ';
                    enter_foxes[num1st + 1] = ' ';
                }
                else
                {
                    if ((y > h_enter) && (y < h_enter + 20))
                    {
                        opt_enter = TREE;
                        stack_enter_tree = 0;
                        enter_tree[num1st] = ' ';
                        enter_tree[num1st + 1] = ' ';
                    }
                }
            }
        }
		break;
	case GAME:
        {
            int i,j;
            y -= attic + real_height - height;
            if ((y >= 0) && (x >= rim))
            {
                if (y < height - rim - attic)
                {
                    if (x <= 10 * size_cell + rim)
                    {
                        x -= rim;
                        x /= size_cell;
                        y /= size_cell;
                        y = 9 - y;
                        switch(button)
                        {
                        case GLUT_LEFT_BUTTON:
                            if (((p1[x][y] == -1) || (p1[x][y] == 0)) && (flags[x][y] == 0) && (a_foxleft > 0) && (p_foxleft > 0))
                            {
                                switch(game_stat){
                                case HARD:
                                    HARD_generous_mozg(x, y);
                                    break;
                                case MEDIUM:
                                    MEDIUM_generous_mozg(x, y);
                                    break;
                                case EASY:
                                    RANDOM_generous_mozg(x, y);
                                    break;
                                };
                            }
                            break;
                        case GLUT_RIGHT_BUTTON:
                            if ((flags[x][y] == 0) && ((p1[x][y] == 0) || (p1[x][y] == -1)))
                            {
                                flags[x][y] = 1;
                            }
                            else
                            {
                                if ((p1[x][y] == 0) || (p1[x][y] == -1))
                                    flags[x][y] = 0;
                            }
                            break;
                        }
                    }
                }
            }
        }
		break;
    case RESULT:
        {

        }
		break;
    case TABLE_REC:
        {
            click_back(x, y);
        }
		break;
    case HELP:
        {
            click_back(x, y);
        }
		break;
    case PAUSE:
        {

        }
		break;
    case ABOUT:
        {
            click_back(x, y);
        }
		break;
    }
    }
    glutPostRedisplay();
}

int main(int argc, char *argv[])
{
    load_textures();
    int i, j;

    win_stat = START;
    opt_enter = NO;

    real_width = width;
    real_height = height;

    for (i = 0; i < 10; ++i)
    {
        for (i = 0; i < 10; ++i)
        {
            flags[i][j] = 0;
        }
    }
    fox_number = 10;
	tree_number = 3;
	srand(time(NULL));

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB);
    glutInitWindowSize(width, height);
    glutCreateWindow("Fox Hunter 2.0");

    glutDisplayFunc(Display);
    glutReshapeFunc(Reshape);
    glutKeyboardFunc(Keyboard);
    glutMouseFunc(MouseFunc);

    glutMainLoop();

    return 0;
}

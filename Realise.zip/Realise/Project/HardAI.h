int HARD_shot_history[2][100]; // Save history of shots here for recalculation. shot_history[0][i] = m, shot_history[1][i] = n
int HARD_shot_number = 0;

int HARD_add_value_a_1(int cell, int val)  // Add value to 1 cell
{
	if ((val > 0) && (cell >= 0)) cell = cell + val;  // If there are >0 foxes visible and cell empty then add value to cell
	if (val == 0) cell = -10;  // -10 if no one fox in column, string or diagonals
	return cell;
}

void HARD_add_value_a(int m, int n)  // Add numbers to array a (need to algorithm)
{
	int i, j, val;
	val = find_fox(p2, m, n, 0);
	a[m][n] = -10;  // We can't shoot to this cell again, so just never look at it again
	for (i = m - 1; i >= 0; i--)  // Going up
	{
		if (a[i][n] == -2) break;
		a[i][n] = HARD_add_value_a_1(a[i][n], val);
	}
	for (i = m + 1; i < 10; i++)  // Going down
	{
		if (a[i][n] == -2) break;
		a[i][n] = HARD_add_value_a_1(a[i][n], val);
	}
	for (j = n - 1; j >= 0; j--)  // Going left
	{
		if (a[m][j] == -2) break;
		a[m][j] = HARD_add_value_a_1(a[m][j], val);
	}
	for (j = n + 1; j < 10; j++)  // Going right
	{
		if (a[m][j] == -2) break;
		a[m][j] = HARD_add_value_a_1(a[m][j], val);
	}
	for (i = m - 1, j = n - 1; (i >= 0) && (j >= 0); i--, j--)  // Going up and left
	{
		if (a[i][j] == -2) break;
		a[i][j] = HARD_add_value_a_1(a[i][j], val);
	}
	for (i = m + 1, j = n - 1; (i < 10) && (j >= 0); i++, j--)  // Going down and left
	{
		if (a[i][j] == -2) break;
		a[i][j] = HARD_add_value_a_1(a[i][j], val);
	}
	for (i = m - 1, j = n + 1; (i >= 0) && (j < 10); i--, j++)  // Going up and right
	{
		if (a[i][j] == -2) break;
		a[i][j] = HARD_add_value_a_1(a[i][j], val);
	}
	for (i = m + 1, j = n + 1; (i < 10) && (j < 10); i++, j++)  // Going down and right
	{
		if (a[i][j] == -2) break;
		a[i][j] = HARD_add_value_a_1(a[i][j], val);
	}
}

void HARD_recalculation()
{
    int i, j;
    for (i = 0; i < 10; i++)
        for (j = 0; j < 10; j++)
            if (a[i][j] != -2)
                a[i][j] = 0;
    for (i = 0; i < HARD_shot_number; i++)
    {
        HARD_add_value_a(HARD_shot_history[0][i], HARD_shot_history[1][i]);
    }
}

int HARD_AI_shoot(int p_foxleft)  // Function works with AI shots
// AI finds the cells with biggest numbers in array a (biggest numbers means bigest chance of fox there) and shoot to random biggest cell
{
	int cells[2][100];  // Array with biggest cells. cells[0][i] = m, cells[1][i] = n
	int maximum = 0, numb = 0, shoot_cell, i, j, m, n;  // maximumimum- maximumimal cell value in array a, numb - number of biggest cells, shoot_cell - cell, chosen for shoot
	for (i = 0; i < 10; i++)
		for (j = 0; j < 10; j++)
			if (a[i][j] >= 0)
            {
				if (a[i][j] > maximum)
				{
					numb = 1;
					maximum= a[i][j];
					cells[0][0] = i;
					cells[1][0] = j;
				}
				else if (a[i][j] == maximum)
				{
					cells[0][numb] = i;
					cells[1][numb] = j;
					numb++;
				}
            }
	shoot_cell = rand() % numb;
	m = cells[0][shoot_cell];
	n = cells[1][shoot_cell];
	HARD_shot_history[0][HARD_shot_number] = m;
	HARD_shot_history[1][HARD_shot_number] = n;
	HARD_shot_number++;
	if (p2[m][n] == -1)
	{
		a[m][n] = -10;
		p_foxleft--;
		p2[m][n] = -3;
		HARD_recalculation();
	}
	else
	{
		p2[m][n] = find_fox(p2, m, n, -3);
		HARD_add_value_a(m, n);
	}
	if (p2[m][n] == 0) p2[m][n] = -10;  // If there is no one foxes in string, column and diagonals, we still need to mark the cell that player shooted here
	return p_foxleft;
}

void HARD_generous_mozg(int x, int y) // ��� ���� ���������
{
    int i, j;
    a_foxleft1 = a_foxleft;
    a_foxleft = player_move(x, y, a_foxleft);

    if (a_foxleft == a_foxleft1)
    {
        ++xod;
    }
    if ((a_foxleft > 0) && (a_foxleft == a_foxleft1))
    {
        if (beg_shots < 3)  // AI need to do some starting random shots
            p_foxleft = random_shoot(p_foxleft);
        else
            p_foxleft = HARD_AI_shoot(p_foxleft);
        while ((p_foxleft < p_foxleft1) && (p_foxleft > 0))  // If fox killed, repeat move
        {
            p_foxleft1 = p_foxleft;
            if (beg_shots < 3)
                p_foxleft = random_shoot(p_foxleft);
            else
                p_foxleft = HARD_AI_shoot(p_foxleft);
        }
        if (beg_shots < 3) beg_shots++;
        move_numb++;
/*        if (move_numb % 10 == 0)
        {
            for (i = 0; i < 10; i++)
                for (j = 0; j < 10; j++)
                {
                    if (a[i][j] > 0) a[i][j] = 0;  // Let's try to clear AI working array sometimes, because after big number of turns algorithm works bad
                }
            beg_shots = 0;  // Start again from the beginning
        } */
    }
}

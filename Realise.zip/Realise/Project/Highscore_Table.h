struct res // Structure of 1 result. Massive of results is Highscore table
{
    char name[16];
    int steps;
    int time;
};

struct res EASY_results[10]; // Arrays with results for easy access from program. Every time it changes, copy it into file in function add_highscore
struct res MEDIUM_results[10];
struct res HARD_results[10];

void init_highscores()
{
    FILE* fp;
    int i;
    fp = fopen("Highscores-hard", "r"); // Check, if special file with Highscore table exists. If no - create it
    if (fp == NULL)
    {
        fp = fopen("Highscores-hard", "w");
        strcpy (HARD_results[0].name, "Overmind"); HARD_results[0].steps = 10, HARD_results[0].time = 180;
        strcpy (HARD_results[1].name, "Steven_Hawking"); HARD_results[1].steps = 11; HARD_results[1].time = 283;
        strcpy (HARD_results[2].name, "Albert_Einstein"); HARD_results[2].steps = 11; HARD_results[2].time = 352;
        strcpy (HARD_results[3].name, "M.Lomonosov"); HARD_results[3].steps = 12; HARD_results[3].time = 299;
        strcpy (HARD_results[4].name, "Pythagoras"); HARD_results[4].steps = 12; HARD_results[4].time = 328;
        strcpy (HARD_results[5].name, "D.Mendeleev"); HARD_results[5].steps = 13; HARD_results[5].time = 326;
        strcpy (HARD_results[6].name, "Steve_Jobs"); HARD_results[6].steps = 13; HARD_results[6].time = 384;
        strcpy (HARD_results[7].name, "Confucius"); HARD_results[7].steps = 15; HARD_results[7].time = 463;
        strcpy (HARD_results[8].name, "Isaac_Newton"); HARD_results[8].steps = 15; HARD_results[8].time = 499;
        strcpy (HARD_results[9].name, "Jimmy_Neutron"); HARD_results[9].steps = 16; HARD_results[9].time = 470;
        for (i = 0; i < 10; i++)
            fprintf(fp, "%s %d %d\n", HARD_results[i].name, HARD_results[i].steps, HARD_results[i].time);
    }
    else
        for (i = 0; i < 10; i++)
            fscanf(fp, "%s %d %d\n", HARD_results[i].name, &HARD_results[i].steps, &HARD_results[i].time);
    fclose(fp);

    fp = fopen("Highscores-medium", "r"); // The same for MEDIUM
    if (fp == NULL)
    {
        fp = fopen("Highscores-medium", "w");
        strcpy (MEDIUM_results[0].name, "Developer"); MEDIUM_results[0].steps = 20; MEDIUM_results[0].time = 300;
        strcpy (MEDIUM_results[1].name, "Jim_Raynor"); MEDIUM_results[1].steps = 26; MEDIUM_results[1].time = 254;
        strcpy (MEDIUM_results[2].name, "Ded_Moroz"); MEDIUM_results[2].steps = 30; MEDIUM_results[2].time = 260;
        strcpy (MEDIUM_results[3].name, "Alexander_II"); MEDIUM_results[3].steps = 32; MEDIUM_results[3].time = 208;
        strcpy (MEDIUM_results[4].name, "Tina_Kandelaki"); MEDIUM_results[4].steps = 32; MEDIUM_results[4].time = 272;
        strcpy (MEDIUM_results[5].name, "Zayats"); MEDIUM_results[5].steps = 35; MEDIUM_results[5].time = 257;
        strcpy (MEDIUM_results[6].name, "Volk"); MEDIUM_results[6].steps = 35; MEDIUM_results[6].time = 258;
        strcpy (MEDIUM_results[7].name, "A.Parovozov"); MEDIUM_results[7].steps = 36; MEDIUM_results[7].time = 199;
        strcpy (MEDIUM_results[8].name, "Barsik"); MEDIUM_results[8].steps = 38; MEDIUM_results[8].time = 357;
        strcpy (MEDIUM_results[9].name, "Your_granny"); MEDIUM_results[9].steps = 40; MEDIUM_results[9].time = 785;
        for (i = 0; i < 10; i++)
            fprintf(fp, "%s %d %d\n", MEDIUM_results[i].name, MEDIUM_results[i].steps, MEDIUM_results[i].time);
    }
    else
        for (i = 0; i < 10; i++)
            fscanf(fp, "%s %d %d\n", MEDIUM_results[i].name, &MEDIUM_results[i].steps, &MEDIUM_results[i].time);
    fclose(fp);

    fp = fopen("Highscores-easy", "r"); // The same for EASY
    if (fp == NULL)
    {
        fp = fopen("Highscores-easy", "w");
        strcpy (EASY_results[0].name, "Lucky_Boy"); EASY_results[0].steps = 29; EASY_results[0].time = 100;
        strcpy (EASY_results[1].name, "Spider_Man"); EASY_results[1].steps = 35; EASY_results[1].time = 438;
        strcpy (EASY_results[2].name, "Jason_Statham"); EASY_results[2].steps = 37; EASY_results[2].time = 401;
        strcpy (EASY_results[3].name, "Gabe_Newell"); EASY_results[3].steps = 41; EASY_results[3].time = 357;
        strcpy (EASY_results[4].name, "Leeeeeeeeeroy"); EASY_results[4].steps = 47; EASY_results[4].time = 395;
        strcpy (EASY_results[5].name, "Flash"); EASY_results[5].steps = 53; EASY_results[5].time = 13;
        strcpy (EASY_results[6].name, "Jar_Jar_Binks"); EASY_results[6].steps = 55; EASY_results[6].time = 285;
        strcpy (EASY_results[7].name, "Grool"); EASY_results[7].steps = 59; EASY_results[7].time = 203;
        strcpy (EASY_results[8].name, "Your_teammate"); EASY_results[8].steps = 75; EASY_results[8].time = 58;
        strcpy (EASY_results[9].name, "Barack_Obama"); EASY_results[9].steps = 104; EASY_results[9].time = 999;
        for (i = 0; i < 10; i++)
            fprintf(fp, "%s %d %d\n", EASY_results[i].name, EASY_results[i].steps, EASY_results[i].time);
    }
    else
        for (i = 0; i < 10; i++)
            fscanf(fp, "%s %d %d\n", EASY_results[i].name, &EASY_results[i].steps, &EASY_results[i].time);
    fclose(fp);
}

void add_highscore(char* name1, int steps1, int time1, GameStatus bot1)
{
    int i, j, k;
    int step_found = 0, position_found = 0;
////////////// EASY ////////////////
    if (bot1 == EASY)
    {
        for (i = 0; i < 10; i++) // Sort by step number before
            {
                if(steps1 < EASY_results[i].steps)
                {
                    position_found = 1;
                    break;
                }
                if (steps1 == EASY_results[i].steps)
                {
                    step_found = 1;
                    break;
                }
            }
        j = i;
        if (step_found)
            for (j = i; j < 10; j++) // Then sort by time of game (if step number and time are equal - old result is better)
                if((time1 < EASY_results[j].time) || (steps1 < EASY_results[j].steps))
                {
                    position_found = 1;
                    break;
                }
        if (position_found)
        {
            if (j == 9)
            {
                EASY_results[9].steps = steps1;
                EASY_results[9].time = time1;
                strcpy(EASY_results[9].name, name1);
            }
            else
            {
                for (k = 9; k > j; k--)
                {
                    EASY_results[k].steps = EASY_results[k - 1].steps;
                    EASY_results[k].time = EASY_results[k - 1].time;
                    strcpy(EASY_results[k].name, EASY_results[k - 1].name);
                }
                EASY_results[j].steps = steps1;
                EASY_results[j].time = time1;
                strcpy(EASY_results[j].name, name1);
            }
        }
    }
////////////// MEDIUM ////////////////
    if (bot1 == MEDIUM)
    {
        for (i = 0; i < 10; i++) // Sort by step number before
            {
                if(steps1 < MEDIUM_results[i].steps)
                {
                    position_found = 1;
                    break;
                }
                if (steps1 == MEDIUM_results[i].steps)
                {
                    step_found = 1;
                    break;
                }
            }
        j = i;
        if (step_found)
            for (j = i; j < 10; j++) // Then sort by time of game (if step number and time are equal - old result is better)
                if((time1 < MEDIUM_results[j].time) || (steps1 < MEDIUM_results[j].steps))
                {
                    position_found = 1;
                    break;
                }
        if (position_found)
        {
            if (j == 9)
            {
                MEDIUM_results[9].steps = steps1;
                MEDIUM_results[9].time = time1;
                strcpy(MEDIUM_results[9].name, name1);
            }
            else
            {
                for (k = 9; k > j; k--)
                {
                    MEDIUM_results[k].steps = MEDIUM_results[k - 1].steps;
                    MEDIUM_results[k].time = MEDIUM_results[k - 1].time;
                    strcpy(MEDIUM_results[k].name, MEDIUM_results[k - 1].name);
                }
                MEDIUM_results[j].steps = steps1;
                MEDIUM_results[j].time = time1;
                strcpy(MEDIUM_results[j].name, name1);
            }
        }
    }
////////////// HARD ////////////////
    if (bot1 == HARD)
    {
        for (i = 0; i < 10; i++) // Sort by step number before
            {
                if(steps1 < HARD_results[i].steps)
                {
                    position_found = 1;
                    break;
                }
                if (steps1 == HARD_results[i].steps)
                {
                    step_found = 1;
                    break;
                }
            }
        j = i;
        if (step_found)
            for (j = i; j < 10; j++) // Then sort by time of game (if step number and time are equal - old result is better)
                if((time1 < HARD_results[j].time) || (steps1 < HARD_results[j].steps))
                {
                    position_found = 1;
                    break;
                }
        if (position_found)
        {
            if (j == 9)
            {
                HARD_results[9].steps = steps1;
                HARD_results[9].time = time1;
                strcpy(HARD_results[9].name, name1);
            }
            else
            {
                for (k = 9; k > j; k--)
                {
                    HARD_results[k].steps = HARD_results[k - 1].steps;
                    HARD_results[k].time = HARD_results[k - 1].time;
                    strcpy(HARD_results[k].name, HARD_results[k - 1].name);
                }
                HARD_results[j].steps = steps1;
                HARD_results[j].time = time1;
                strcpy(HARD_results[j].name, name1);
            }
        }
    }
/////////// Printing into file //////////
    FILE* fp;
    if (bot1 == EASY)
    {
        fp = fopen("Highscores-easy", "w");
        for (i = 0; i < 10; i++)
            fprintf(fp, "%s %d %d\n", EASY_results[i].name, EASY_results[i].steps, EASY_results[i].time);
    }
    if (bot1 == MEDIUM)
    {
        fp = fopen("Highscores-medium", "w");
        for (i = 0; i < 10; i++)
            fprintf(fp, "%s %d %d\n", MEDIUM_results[i].name, MEDIUM_results[i].steps, MEDIUM_results[i].time);
    }
    if (bot1 == HARD)
    {
        fp = fopen("Highscores-hard", "w");
        for (i = 0; i < 10; i++)
            fprintf(fp, "%s %d %d\n", HARD_results[i].name, HARD_results[i].steps, HARD_results[i].time);
    }
    fclose(fp);
}

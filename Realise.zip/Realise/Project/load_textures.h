
void scroll_image_bmp(FILE * in)
{
    unsigned char c;
	unsigned int i;
    for (i = 0; i < 54; ++i)
	{
		c = getc(in);
	}
}

#define DRAWCHAR(x) glDrawPixels(wchar, 20, GL_RGB, GL_UNSIGNED_BYTE, chars[5080-x*20])

#define wchar 12
#define hchars 5100
GLubyte chars[hchars][wchar][3];

void load_texture_chars()
{

	unsigned char c;
	unsigned int i, j;
	FILE * in  = fopen ("res/chars.bmp", "rb");
	scroll_image_bmp(in);

	for (i = 0; i < hchars; ++i)
	{
		for (j = 0; j < wchar; ++j)
        {
            chars[i][j][2] = getc(in);
            chars[i][j][1] = getc(in);
            chars[i][j][0] = getc(in);
        }
	}
	fclose (in);
}

#define w_FH 420
#define h_FH 84
GLubyte im_FH[w_FH][h_FH][3];
void load_texture_FH()
{
	unsigned char c;
	unsigned int i, j;
	FILE * in  = fopen ("res/start/FH.bmp", "rb");
	scroll_image_bmp(in);

	for (i = 0; i < w_FH; ++i)
	{
		for (j = 0; j < h_FH; ++j)
        {
            im_FH[i][j][2] = getc(in);
            im_FH[i][j][1] = getc(in);
            im_FH[i][j][0] = getc(in);
        }
	}
	fclose (in);
}

#define w_but 212
#define h_but 64
GLubyte im_but_play[w_but][h_but][3];
void load_texture_button_play()
{
	unsigned char c;
	unsigned int i, j;
	FILE * in  = fopen ("res/start/play.bmp", "rb");
	scroll_image_bmp(in);

	for (i = 0; i < w_but; ++i)
	{
		for (j = 0; j < h_but; ++j)
        {
            im_but_play[i][j][2] = getc(in);
            im_but_play[i][j][1] = getc(in);
            im_but_play[i][j][0] = getc(in);
        }
	}
	fclose (in);
}

GLubyte im_but_records[w_but][h_but][3];
void load_texture_button_records()
{
	unsigned char c;
	unsigned int i, j;
	FILE * in  = fopen ("res/start/records.bmp", "rb");
	scroll_image_bmp(in);

	for (i = 0; i < w_but; ++i)
	{
		for (j = 0; j < h_but; ++j)
        {
            im_but_records[i][j][2] = getc(in);
            im_but_records[i][j][1] = getc(in);
            im_but_records[i][j][0] = getc(in);
        }
	}
	fclose (in);
}

GLubyte im_but_about[w_but][h_but][3];
void load_texture_button_about()
{
	unsigned char c;
	unsigned int i, j;
	FILE * in  = fopen ("res/start/about.bmp", "rb");
	scroll_image_bmp(in);

	for (i = 0; i < w_but; ++i)
	{
		for (j = 0; j < h_but; ++j)
        {
            im_but_about[i][j][2] = getc(in);
            im_but_about[i][j][1] = getc(in);
            im_but_about[i][j][0] = getc(in);
        }
	}
	fclose (in);
}

GLubyte im_but_help[w_but][h_but][3];
void load_texture_button_help()
{
	unsigned char c;
	unsigned int i, j;
	FILE * in  = fopen ("res/start/help.bmp", "rb");
	scroll_image_bmp(in);

	for (i = 0; i < w_but; ++i)
	{
		for (j = 0; j < h_but; ++j)
        {
            im_but_help[i][j][2] = getc(in);
            im_but_help[i][j][1] = getc(in);
            im_but_help[i][j][0] = getc(in);
        }
	}
	fclose (in);
}

GLubyte im_but_diff[w_but][h_but][3];
void load_texture_button_diff()
{
	unsigned char c;
	unsigned int i, j;
	FILE * in  = fopen ("res/start/options/difficult.bmp", "rb");
	scroll_image_bmp(in);

	for (i = 0; i < w_but; ++i)
	{
		for (j = 0; j < h_but; ++j)
        {
            im_but_diff[i][j][2] = getc(in);
            im_but_diff[i][j][1] = getc(in);
            im_but_diff[i][j][0] = getc(in);
        }
	}
	fclose (in);
}

GLubyte im_but_med[w_but][h_but][3];
void load_texture_button_med()
{
	unsigned char c;
	unsigned int i, j;
	FILE * in  = fopen ("res/start/options/medium.bmp", "rb");
	scroll_image_bmp(in);

	for (i = 0; i < w_but; ++i)
	{
		for (j = 0; j < h_but; ++j)
        {
            im_but_med[i][j][2] = getc(in);
            im_but_med[i][j][1] = getc(in);
            im_but_med[i][j][0] = getc(in);
        }
	}
	fclose (in);
}

GLubyte im_but_easy[w_but][h_but][3];
void load_texture_button_easy()
{
	unsigned char c;
	unsigned int i, j;
	FILE * in  = fopen ("res/start/options/easy.bmp", "rb");
	scroll_image_bmp(in);

	for (i = 0; i < w_but; ++i)
	{
		for (j = 0; j < h_but; ++j)
        {
            im_but_easy[i][j][2] = getc(in);
            im_but_easy[i][j][1] = getc(in);
            im_but_easy[i][j][0] = getc(in);
        }
	}
	fclose (in);
}

GLubyte im_but_back[w_but][h_but][3];
void load_texture_button_back()
{
	unsigned char c;
	unsigned int i, j;
	FILE * in  = fopen ("res/back.bmp", "rb");
	scroll_image_bmp(in);

	for (i = 0; i < w_but; ++i)
	{
		for (j = 0; j < h_but; ++j)
        {
            im_but_back[i][j][2] = getc(in);
            im_but_back[i][j][1] = getc(in);
            im_but_back[i][j][0] = getc(in);
        }
	}
	fclose (in);
}

#define w_cat 80
#define h_cat 80
GLubyte im_cat[w_cat][h_cat][3];
void load_texture_cat_play()
{
	unsigned char c;
	unsigned int i, j;
	FILE * in  = fopen ("res/start/cat.bmp", "rb");
	scroll_image_bmp(in);

	for (i = 0; i < w_cat; ++i)
	{
		for (j = 0; j < h_cat; ++j)
        {
            im_cat[i][j][2] = getc(in);
            im_cat[i][j][1] = getc(in);
            im_cat[i][j][0] = getc(in);
        }
	}
	fclose (in);
}

load_textures()
{
    load_texture_chars();

    load_texture_button_play();
    load_texture_button_records();
    load_texture_button_about();
    load_texture_button_help();

    load_texture_button_easy();
    load_texture_button_med();
    load_texture_button_diff();
    load_texture_button_back();

    load_texture_cat_play();
    load_texture_FH();
}

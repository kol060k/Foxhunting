void RANDOM_generous_mozg(int x, int y) // ��� ���� ���������
{
    int i, j;
    a_foxleft1 = a_foxleft;
    a_foxleft = player_move(x, y, a_foxleft);

    if (a_foxleft == a_foxleft1)
    {
        ++xod;
    }
    if ((a_foxleft > 0) && (a_foxleft == a_foxleft1))
    {
        p_foxleft = random_shoot(p_foxleft);
        while ((p_foxleft < p_foxleft1) && (p_foxleft > 0))  // If fox killed, repeat move
        {
            p_foxleft1 = p_foxleft;
            p_foxleft = random_shoot(p_foxleft);
        }
        move_numb++;
    }
}

int find_fox(int p[10][10], int m, int n, int setting)  // Function of searching foxes in strings, columns and diagonals
// if (setting == -3) then we count dead foxes
// else we don't count
{
	int numb = 0, i, j;
	for (i = m - 1; i >= 0; i--)  // Going up
	{
		if (p[i][n] == -2) break;
		if (p[i][n] == -1) numb++;
		if ((p[i][n] == -3) && (setting == -3)) numb++;
	}
	for (i = m + 1; i < 10; i++)  // Going down
	{
		if (p[i][n] == -2) break;
		if (p[i][n] == -1) numb++;
		if ((p[i][n] == -3) && (setting == -3)) numb++;
	}
	for (j = n - 1; j >= 0; j--)  // Going left
	{
		if (p[m][j] == -2) break;
		if (p[m][j] == -1) numb++;
		if ((p[m][j] == -3) && (setting == -3)) numb++;
	}
	for (j = n + 1; j < 10; j++)  // Going right
	{
		if (p[m][j] == -2) break;
		if (p[m][j] == -1) numb++;
		if ((p[m][j] == -3) && (setting == -3)) numb++;
	}
	for (i = m - 1, j = n - 1; (i >= 0) && (j >= 0); i--, j--)  // Going up and left
	{
		if (p[i][j] == -2) break;
		if (p[i][j] == -1) numb++;
		if ((p[i][j] == -3) && (setting == -3)) numb++;
	}
	for (i = m + 1, j = n - 1; (i < 10) && (j >= 0); i++, j--)  // Going down and left
	{
		if (p[i][j] == -2) break;
		if (p[i][j] == -1) numb++;
		if ((p[i][j] == -3) && (setting == -3)) numb++;
	}
	for (i = m - 1, j = n + 1; (i >= 0) && (j < 10); i--, j++)  // Going up and right
	{
		if (p[i][j] == -2) break;
		if (p[i][j] == -1) numb++;
		if ((p[i][j] == -3) && (setting == -3)) numb++;
	}
	for (i = m + 1, j = n + 1; (i < 10) && (j < 10); i++, j++)  // Going down and right
	{
		if (p[i][j] == -2) break;
		if (p[i][j] == -1) numb++;
		if ((p[i][j] == -3) && (setting == -3)) numb++;
	}
	return numb;
}

int player_move(int x, int y, int a_foxleft)  // Function that works with player's turn
{
	if (p1[x][y] == 0) p1[x][y] = find_fox(p1, x, y, -3);
	else
	{
		p1[x][y] = -3;
		a_foxleft--;
	}
	if (p1[x][y] == 0) p1[x][y] = -10;  // If there is no one foxes in string, column and diagonals, we still need to mark the cell that player shooted here
	return a_foxleft;
}

int random_shoot(int p_foxleft)  // Starting random AI shots
{
	int m, n, right_shot = 0;  // m, n - numbers of string and column; right_shot - checker if shot correct
	while (right_shot == 0)
	{
		m = rand() % 10;
		n = rand() % 10;
		if ((p2[m][n] == 0) || (p2[m][n] == -1))
			right_shot = 1;
	}
	if (p2[m][n] == 0)
	{
		p2[m][n] = find_fox(p2, m, n, -3);
	}
	else
	{
		a[m][n] = -10;
		p2[m][n] = -3;
		p_foxleft--;
	}
	if (p2[m][n] == 0) p2[m][n] = -10;  // If there is no one foxes in string, column and diagonals, we still need to mark the cell that player shooted here
	return p_foxleft;
}

void generous_mozg(int x, int y) // ��� ���� ���������
{
    int i, j;
    a_foxleft1 = a_foxleft;
    a_foxleft = player_move(x, y, a_foxleft);

    if (a_foxleft == a_foxleft1)
    {
        ++xod;
    }
    if ((a_foxleft > 0) && (a_foxleft == a_foxleft1))
    {
        p_foxleft = random_shoot(p_foxleft);
        while ((p_foxleft < p_foxleft1) && (p_foxleft > 0))  // If fox killed, repeat move
        {
            p_foxleft1 = p_foxleft;
            p_foxleft = random_shoot(p_foxleft);
        }
        move_numb++;
    }
}

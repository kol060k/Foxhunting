void write_string(int x, int y, char* str, int n)
{
    int i;
    for (i = 0; i < n; ++i)
    {
        glRasterPos2i(x + i*wchar, y);
        DRAWCHAR(str[i]);
    }
}

void draw_FH()
{
    glRasterPos2i((width - w_FH)/2, height - h_FH);
    glDrawPixels(
        w_FH,
        h_FH,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_FH);
}

void draw_buttons()
#define height_button 70
#define shift_height_button 70
{
    glRasterPos2i(width/2 - w_but/2, height_button + 3*shift_height_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_play);

    glRasterPos2i(width/2 - w_but/2, height_button + 2*shift_height_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_records);

    glRasterPos2i(width/2 - w_but/2, height_button + shift_height_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_help);

    glRasterPos2i(width/2 - w_but/2, height_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_about);
}

#define shift_button_rec 250
draw_buttons_rec()
{
    glRasterPos2i(width/2 - w_but/2 - shift_button_rec + 20*(game_stat == HARD), height_button + 3*shift_height_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_diff);

    glRasterPos2i(width/2 - w_but/2 - shift_button_rec + 20*(game_stat == MEDIUM), height_button + 2*shift_height_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_med);

    glRasterPos2i(width/2 - w_but/2 - shift_button_rec + 20*(game_stat == EASY), height_button + shift_height_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_easy);
}

#define left_shift_table 300
#define up_shift_table 140
void draw_table_rec(struct res* table)
{
    int i;
    char c[10];
    for (i = 0; i < 10; ++i)
    {
        c[0] = '0' + (char)((i + 1) / 10);
        c[1] = '0' + (char)((i + 1) % 10);
        c[2] = ' ';
        write_string(left_shift_table, height - up_shift_table - i*20, c, 3);

        write_string(left_shift_table + 3*wchar, height - up_shift_table - i*20, table[i].name, 15);

        c[0] = '0';
        c[0] += table[i].steps /100;
        c[1] = '0';
        c[1] += table[i].steps % 100 / 10;
        c[2] = '0';
        c[2] += table[i].steps % 10;
        write_string(left_shift_table + 18*wchar, height - up_shift_table - i*20, c, 3);

        c[6] = ' ';
        c[5] = '0';
        c[5] += table[i].time % 10;
        c[4] = '0';
        c[4] += (table[i].time % 60) / 10;
        c[3] = ':';
        c[2] = '0';
        c[2] += (table[i].time % 600) / 60;
        c[1] = '0';
        c[1] += (table[i].time % 3600) / 600;
        c[0] = ' ';
        write_string(left_shift_table + 21*wchar, height - up_shift_table - i*20, c, 7);
    }
}

void draw_buttons_options()
#define shift_button 100
{
    glRasterPos2i(width/2 - w_but/2 - shift_button, height_button + 3*shift_height_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_diff);

    glRasterPos2i(width/2 - w_but/2 - shift_button, height_button + 2*shift_height_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_med);

    glRasterPos2i(width/2 - w_but/2 - shift_button, height_button + shift_height_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_easy);

    glRasterPos2i(width/2 - w_but/2 - shift_button, height_back_button);
    glDrawPixels(
        w_but,
        h_but,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_but_back);
}
void draw_cat()
{
    glRasterPos2i(real_width - w_cat, 0);
    glDrawPixels(
        w_cat,
        h_cat,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        im_cat);
}
